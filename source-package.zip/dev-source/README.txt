DEV.IO 个人主页 - 开发源码包
==============================
index.html / test.html  当前线上最终版本 (v6)
index-v6.html   v6 快照（图标修复 + 邮箱复制交互）
index-v5.html   v5 快照（真实社交链接 + 品牌图标）
index-v4.html   v4 快照（个人背景 + GMP 作品）
index-v3.html   v3 快照（导航修复 + 繁简统一）
template.html   带 /*__FONTS__*/ 占位符的可维护源模板
orbitron.woff2  标题字体（内嵌于最终 HTML）
rajdhani.woff2  副标题字体（内嵌于最终 HTML）
CHANGELOG.md    全部版本优化记录

字体注入方式：将 woff2 转 base64 后替换 template.html 中的 /*__FONTS__*/。
最终页面零第三方库依赖，单文件交付。
